from django.apps import AppConfig


class AdventureAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'adventure_app'
